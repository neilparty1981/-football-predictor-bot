# Football Predictor Bot V2 — Mobile + Self-Learning

FootballBot V2 turns V1 into a phone-friendly Streamlit web app and adds a conservative self-learning calibration layer.

## Markets
- Home / Draw / Away (1X2)
- Over 1.5 goals
- Over 2.5 goals
- Over 3.5 goals
- Both Teams To Score (BTTS Yes)
- Exact 1-1 probability and daily Top 5 1-1 candidates
- Model fair odds for each tracked market

## Leagues
England: Premier League, Championship, League One, League Two  
Scotland: Premiership, Championship, League One, League Two  
Germany: Bundesliga, 2. Bundesliga  
Italy: Serie A, Serie B  
Spain: La Liga, Segunda Division  
France: Ligue 1, Ligue 2  
Netherlands: Eredivisie  
Belgium: First Division A  
Portugal: Primeira Liga  
Turkey: Super Lig

## What "self-learning" means
V2 does not blindly chase yesterday's winners. On each refresh it:
1. Downloads the latest completed match history.
2. Trains its Poisson attack/defence model on older matches.
3. Tests probabilities on a chronological holdout period.
4. Learns a logistic calibration for 1X2, totals, BTTS and 1-1 probabilities.
5. Retrains the final base model on all available completed matches.
6. Applies the learned calibration to upcoming fixtures.
7. Shows Brier-score performance so you can see whether calibration actually helped.

Because the learning is rebuilt from the latest source data, it does not depend on a laptop staying switched on or on a fragile local state file.

## Run locally
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
streamlit run streamlit_app.py
```

## Deploy for phone use (recommended)
The easiest route is Streamlit Community Cloud:
1. Create/sign into a GitHub account.
2. Create a repository and upload this project (all files in this folder, not the outer zip folder).
3. Sign into Streamlit Community Cloud with GitHub.
4. Choose **Create app** / **Deploy**.
5. Select your repository and set the main file to `streamlit_app.py`.
6. Deploy. Streamlit will give you a URL ending in `.streamlit.app`.
7. Open that URL on your iPhone. In Safari, use **Share → Add to Home Screen** for an app-like icon.

After deployment, the laptop can be off. The app downloads/retrains on the cloud when its cache refreshes or when you press **Refresh latest data**.

## Mobile dashboard
The app contains:
- Fixtures table with all tracked probabilities
- Top 5 likely 1-1 results
- Best selection by market
- Self-learning/Brier score page
- League/date filters
- CSV export

## Data
V2 uses Football-Data.co.uk CSV results and fixtures. Availability/timing of upcoming fixture data is controlled by that source. A future V3 can add a live fixture/odds API and compare bookmaker/Betfair prices with model fair odds.

## Important
Predictions are uncertain estimates, not guaranteed bets. Validate with out-of-sample backtests and compare with available market prices before staking money.
