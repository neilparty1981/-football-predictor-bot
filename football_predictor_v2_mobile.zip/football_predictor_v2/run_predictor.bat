@echo off
python -m football_bot.main predict --days 7 --output predictions.csv
pause
