#!/usr/bin/env bash
python -m football_bot.main predict --days 7 --output predictions.csv
