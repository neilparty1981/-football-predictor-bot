import numpy as np
import pandas as pd

from football_bot.learning import LogisticCalibrator
from football_bot.model import LeaguePoissonModel

# Calibration sanity check
p = np.linspace(0.05, 0.95, 300)
y = (p > 0.55).astype(int)
cal = LogisticCalibrator().fit(p, y)
assert 0 < cal.transform(0.25) < cal.transform(0.75) < 1

# Model sanity check with synthetic league history
rows = []
dates = pd.date_range("2025-01-01", periods=80, freq="D")
teams = ["A", "B", "C", "D"]
for i, dt in enumerate(dates):
    h = teams[i % 4]
    a = teams[(i + 1) % 4]
    rows.append({"Div":"X1", "Date":dt, "HomeTeam":h, "AwayTeam":a, "FTHG":int(i % 3), "FTAG":int((i + 1) % 2)})
hist = pd.DataFrame(rows)
model = LeaguePoissonModel().fit(hist)
probs = model.probabilities("X1", "A", "B")
assert abs(probs["Home"] + probs["Draw"] + probs["Away"] - 1.0) < 1e-9
assert 0 <= probs["P_1-1"] <= 1
print("FootballBot V2 smoke tests passed")
